import './Todo.css'

const Todo = (props) => {
    return (
        <div>
            <div className='text'>
                {props.name}
                <div className='img'>
                    <span>{props.done}</span>
                    <span>{props.remove}</span>
                </div>
            </div>
        </div>
    )
}

export default Todo