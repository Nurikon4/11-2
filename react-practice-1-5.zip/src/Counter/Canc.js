import React,{ Component } from "react";

class Canc extends Component {
    
    state = {
        calc: 0
    }
    
    render() {
        return (
            <div>
                <h2>Calc {this.state.calc}</h2>
                <button onClick={ () => this.setState({calc: this.state.calc + 1})}>+</button>
                <button onClick={ () => this.setState({calc: this.state.calc -1})}>-</button>
            </div>
        )
    }
}

export default Canc 