import React, { Component } from 'react'
import './App.css';
import Todo from './Todo/Todo';

class App extends Component {

  state = {
    text: '',
    tasks: []
  }

  onChange = (e) => {
    this.setState({
      text: e.target.value
    })
  }

  onAdd = () => {
    const tasks = this.state.tasks
    tasks.push(this.state.text)
    this.setState({ tasks: tasks, text: '' })
  }

  onRemove = () => {
    this.setState({})
  }

  render() { 

    return (
      <div style={{ textAlign: 'center' }}>
        <h1>ToDoList</h1>
        <input className="input" onChange={this.onChange} value={this.state.text} type="text" placeholder='Введите задачу'></input>
        <button onClick={this.onAdd}>Добавить</button>

        {this.state.tasks.map(task => (
          <Todo name={task} done={<button>Done</button>} remove={<button onClick={this.onRemove}>Remove</button>}/>
        ))}

      </div>
    )
  }
}

export default App;
