import MyPosts from './MyPosts/MyPosts'
import classes  from './Profile.module.css'
import Profileifno from './ProfileInfo/Profileinfo'

const Profile= (props) => {

    return (
        <div className={classes.content}>
            <Profileifno />

            <MyPosts postData={props.postData} onbtn={props.onbtn}/>
        </div>
    )
}
    export default Profile