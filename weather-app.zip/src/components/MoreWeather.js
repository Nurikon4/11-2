import { NavLink } from "react-router-dom"
import Container from "./Container/Container"
import classes from './MoreWeather.module.css'


function MoreWeather() {
    return (
        <div className={classes.MoreWeather}>
            <NavLink className={classes.goback} to="/">Вернуться назад</NavLink>
            <h1 className={classes.uptitle}>City</h1>
            <Container />
        </div>
    )
}

export default MoreWeather
