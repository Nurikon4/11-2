import classes from './Navbar.module.css'
import { NavLink } from 'react-router-dom'

const Navbar = () => {
    return (
        <nav className={classes.nav}>
            <div className={classes.item}>
                <NavLink to="/profile" activeClassName={classes.active}>Profile</NavLink>
            </div>
            <div className={` ${classes.item} ${classes.active} `}>
                <NavLink to="/dialogs" activeClassName={classes.active}>Message</NavLink>
            </div>
            <div className={classes.item}>
                <NavLink to="/news" activeClassName={classes.active}>News</NavLink>
            </div>
            <div className={classes.item}>
                <NavLink to="/music" activeClassName={classes.active}>Music</NavLink>
            </div>
            <div className={classes.item}>
                <NavLink to="/settings" activeClassName={classes.active}>Settings</NavLink>
            </div>
            <div className={classes.item__friends}>
                <NavLink to="/friends" activeClassName={classes.active}>Friends</NavLink>
                <div className={classes.circle}>
                    <div>
                        <div className={classes.bg}></div>
                        <p>Andrew</p>
                    </div>
                    <div>
                        <div className={classes.bg}></div>
                        <p>Sasha</p>
                    </div>
                    <div>
                        <div className={classes.bg}></div>
                        <p>Sveta</p>
                    </div>
                </div>
            </div>
        </nav>
    )
}
export default Navbar