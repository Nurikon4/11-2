let state = {
    ProfilePages : {
      postData: [
        {id: 1, message: 'TTT', likescount: 12},
        {id: 2, message: 'EEE', likescount: 15},
        {id: 3, message: 'Hellow', likescount: 20},
        {id: 4, message: 'SSS', likescount: 25},
        {id: 5, message: 'TTT', likescount: 12},
        {id: 6, message: 'r', likescount: 12}
      ],
    },

    MessagesPage: {
      diaglogsData: [
        {id: 1, name: 'Dimych'},
        {id: 2, name: 'Andrey'},
        {id: 3, name: 'Sveta'},
        {id: 4, name: 'Sasha'},
        {id: 5, name: 'Viktor'},
        {id: 6, name: 'Valera'}
      ],

      messages: [
        {id: 1, message: 'Hi'},
        {id: 2, message: 'Hello'},
        {id: 3, message: 'Hellow'},
        {id: 4, message: 's'},
        {id: 5, message: 'q'},
        {id: 6, message: 'r'}
      ]
    },
      SidePade: {
        
      }
}

export let addPost = (postMessage) => {
  let newPost = {
    id: 5,
    message: postMessage,
    likesCont: 0s
  }
  state.ProfilePages.postData.push(newPost)
  rerenderEntireTree(state)
}

export default state;