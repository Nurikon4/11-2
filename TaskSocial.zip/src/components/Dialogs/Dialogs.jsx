import DialogItem from './Dialogitem/Dialogsitem'
import classes from './Dialogs.module.css'
import Message from './Message/message'

let diaglogsData = [
    {id: 1, name: 'Dimych'},
    {id: 2, name: 'Andrey'},
    {id: 3, name: 'Sveta'},
    {id: 4, name: 'Sasha'},
    {id: 5, name: 'Viktor'},
    {id: 6, name: 'Valera'}
]

let dialogsElemnts = diaglogsData
.map ( dialog => <DialogItem name={dialog.name} id={dialog.id}/> ) 

let messages = [
    {id: 1, message: 'Hi'},
    {id: 2, message: 'Hello'},
    {id: 3, message: 'Hellow'},
    {id: 4, message: 's'},
    {id: 5, message: 'q'},
    {id: 6, message: 'r'}
]

let messagesElements = messages
.map ( message => <Message message={message.message}/> )

const Dialogs = (props) => {
    return (
        <div className={classes.dialogs}>
            <div className={classes.dialogsItems}>
                {dialogsElemnts}
            </div>
            <div className={classes.messages}>
                {messagesElements}
            </div>
        </div>
    )
}

export default Dialogs