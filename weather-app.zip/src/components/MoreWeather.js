import { NavLink } from "react-router-dom"
import classes from './MoreWeather.module.css'

function MoreWeather() {
    return (
        <div className={classes.MoreWeather}>
            <NavLink className={classes.goback} to="/">Вернуться назад</NavLink>
            <h1 className={classes.uptitle}>City</h1>
            <div className={classes.container}>
                <div className={classes.title}>
                    <h2>Сегодня</h2>
                </div>
                <div className={classes.items}>

                    <div className={classes.item}>
                        <div className={classes.block}>
                            <p className={classes.data}>18 марта, 12:00</p>
                            <div className={classes.degree__block}>
                                <img className={classes.img}></img>
                                <div className={classes.degree}>5<sup>&deg;</sup>С</div>
                            </div>
                            <div className={classes.info}>Ясно</div>
                            <div className={classes.how}>Ощущается как: 1<sup>&deg;</sup>C</div>
                        </div>
                    </div>

                    <div className={classes.item}>
                        <div className={classes.block}>
                            <p className={classes.data}>18 марта, 12:00</p>
                            <div className={classes.degree__block}>
                                <img className={classes.img}></img>
                                <div className={classes.degree}>5<sup>&deg;</sup>С</div>
                            </div>
                            <div className={classes.info}>Ясно</div>
                            <div className={classes.how}>Ощущается как: 1<sup>&deg;</sup>C</div>
                        </div>
                    </div>

                    <div className={classes.item}>
                        <div className={classes.block}>
                            <p className={classes.data}>18 марта, 12:00</p>
                            <div className={classes.degree__block}>
                                <img className={classes.img}></img>
                                <div className={classes.degree}>5<sup>&deg;</sup>С</div>
                            </div>
                            <div className={classes.info}>Ясно</div>
                            <div className={classes.how}>Ощущается как: 1<sup>&deg;</sup>C</div>
                        </div>
                    </div>

                    <div className={classes.item}>
                        <div className={classes.block}>
                            <p className={classes.data}>18 марта, 12:00</p>
                            <div className={classes.degree__block}>
                                <img className={classes.img}></img>
                                <div className={classes.degree}>5<sup>&deg;</sup>С</div>
                            </div>
                            <div className={classes.info}>Ясно</div>
                            <div className={classes.how}>Ощущается как: 1<sup>&deg;</sup>C</div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    )
}

export default MoreWeather
