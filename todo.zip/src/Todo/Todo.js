import './Todo.scss'

const Todo = (props) => {
    

    return (
        <div>
            <div className='text'>
                {props.name}
                <div className='img'>
                    <button onClick={props.done}>Выполнено</button>
                    <button onClick={props.remove}>Удалить</button>
                </div>
            </div>
        </div>
    )
}

export default Todo