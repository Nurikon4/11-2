import classes from './Container.module.css'
import WeatherItem from "../WeatherItem/WeatherItem"
import { useEffect, useState } from 'react'


function Container({moreWeather, data}) {
    return (
        <div className={classes.container}>
            <div className={classes.title}>
                <h2>{data}</h2>
            </div>
            <div className={classes.items}>
                <WeatherItem moreWeather={moreWeather}
                // data={moreWeatherlist.[0].dt_txt}
                // img={moreWeatherlist.[0].weather[0].icon}
                // degree={moreWeatherlist.[0].main.temp}
                // info={moreWeatherlist.[0].weather[0].main}
                // how={moreWeatherlist.[0].main.feels_like}
                />
            </div>
        </div>
    )
}
// lang=ru

export default Container
