import classes  from './MyPosts.module.css'
import Post from './Post/Post'


const MyPosts= (props) => {
    
    let postsElemts = props.postData
    .map( p => <Post message={p.message} likescount={p.likescount}/>)

    return (
        <div className={classes.postsBlock}>
            <h3>My posts</h3>
            <div>
                <div>
                    <textarea id='test'></textarea>
                </div>
            
                <div>
                    <button onClick={props.onbtn}>Add post</button>
                </div>
            </div>
            <div className={classes.posts}>
                {postsElemts}
            </div>
        </div>
    )
}
    export default MyPosts