import JoinBlock from './components/JoinBlock'

function App(){
  return (
    <div className="wrapper">
      <JoinBlock />
    </div>
  );
}

export default App;
