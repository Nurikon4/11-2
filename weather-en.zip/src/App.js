import { Route } from 'react-router'
import MoreWeather from './components/MoreWeather';
import Weather from './components/Weather'
import Loader from './Loader/Loader';


function App() {
  return (
    {Weather}
    ?<div className='wrapper'>
      <Route exact path="/" component={Weather}/>
      <Route exact path="/more" component={MoreWeather}/>
    </div> 
    : <Loader />
  )
}

export default App;
