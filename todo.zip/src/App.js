import React, { Component } from 'react'
import './App.css';
import Todo from './Todo/Todo';

class App extends Component {

  state = {
    text: '',
    tasks: [],
    done: []
  }

  onChange = (e) => {
    this.setState({
      text: e.target.value
    })
  }

  onAdd = () => {
    let tasks = this.state.tasks
    tasks.push(this.state.text)
    this.setState({ tasks: tasks, text: '' })
  }

  onDone(index){
    const done = this.state.tasks.concat()
    this.setState({
      done: done
    })
  }
  onRemove(index) {
    const tasks = this.state.tasks.concat()
    tasks.splice(index, 1)
    this.setState({
      tasks
    })
  }

  render() {
    
    const input = ['input']
    if(this.text != '' ){
      input.push('green')
    } else {
      input.push('red')
    }

    return (
      <div className="container">
        <h1>ToDoList</h1>
        <input className={input.join(' ')} onChange={this.onChange} value={this.state.text} type="text" placeholder='Введите задачу'></input>
        <button onClick={this.onAdd}>Добавить</button>

        {this.state.tasks.map( (task, index) => (
          <Todo name={task} done={this.onDone.bind(this, index)} remove={this.onRemove.bind(this, index)} />
        ))}

        <div className='Done'>
          Выполнено:
          {this.state.done.map( name => {
            return ( 
            <div className='Done__text'>{name}</div>
            )
          })}
        </div>
        
      </div>
    )
  }
}

export default App;
