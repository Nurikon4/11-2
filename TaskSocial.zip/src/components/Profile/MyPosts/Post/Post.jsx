import classes  from './Post.module.css'

const Post= (props) => {
    return (
        <div className={classes.item}>
            <img src='https://shutniki.club/wp-content/uploads/2019/12/maxresdefault-10.jpg' />
            {props.message}
            <div>
                <span>Like</span> {props.likescount}
            </div>
        </div>

    )
}
    export default Post