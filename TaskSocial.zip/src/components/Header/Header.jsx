import classes from './Header.module.css';

const Header= () => {
    return (
        <header className={classes.header}>
        <img src='https://clipart-best.com/img/intel/intel-clip-art-10.png'/>
        </header>
    )
}
    export default Header