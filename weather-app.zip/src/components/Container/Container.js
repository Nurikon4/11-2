import classes from './Container.module.css'
import WeatherItem from "../WeatherItem/WeatherItem"


function Container() {
    return (
        <div className={classes.container}>
            <div className={classes.title}>
                <h2>Сегодня</h2>
            </div>
            <div className={classes.items}>
                <WeatherItem />
                <WeatherItem />
                <WeatherItem />
                <WeatherItem />
                <WeatherItem />
                <WeatherItem />
            </div>
        </div>
    )
}

export default Container
