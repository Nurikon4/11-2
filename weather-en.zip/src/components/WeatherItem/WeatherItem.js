import { useEffect, useState } from 'react'
import classes from './WeatherItem.module.css'

function WeatherItem({ data, img, degree, info, how, moreWeather }) {

    console.log(moreWeather)
    return (
        <div className={classes.item}>
            {moreWeather.list.map((item, index) => (
                <div key={index} className={classes.block}>
                    <p className={classes.data}>{item.dt_txt}</p>
                    <div className={classes.degree__block}>
                        <img className={classes.img} src={`https://openweathermap.org/img/wn/${item.weather[0].icon}@2x.png`}></img>
                        <div className={classes.degree}>{Math.round(item.main.temp)}<sup>&deg;</sup>С</div>
                    </div>
                    <div className={classes.info}>{item.weather[0].description}</div>
                    <div className={classes.how}>Ощущается как: {Math.round(item.main.feels_like)}<sup>&deg;</sup>C</div>
                </div>
            ))}
        </div>
    )
}

export default WeatherItem
