import classes from './Loader.module.css'

function Loader() {
    return (
        <div class={classes.lds}><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
    )
}

export default Loader
