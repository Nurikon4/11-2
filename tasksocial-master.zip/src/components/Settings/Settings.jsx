import classes from './Settings.module.css'

const Settings = (props) => {
    return (
        <div>
            Settings
        </div>
    )
}

export default Settings