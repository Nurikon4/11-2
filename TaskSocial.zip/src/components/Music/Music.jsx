import classes from './Music.module.css'

const Music = (props) => {
    return (
        <div>
            Music
        </div>
    )
}

export default Music