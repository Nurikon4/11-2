import React from 'react'
import classes from './WeatherItem.module.css'

function WeatherItem() {
    return (
        <div className={classes.item}>
            <div className={classes.block}>
                <p className={classes.data}>18 марта, 12:00</p>
                <div className={classes.degree__block}>
                    <img className={classes.img}></img>
                    <div className={classes.degree}>5<sup>&deg;</sup>С</div>
                </div>
                <div className={classes.info}>Ясно</div>
                <div className={classes.how}>Ощущается как: 1<sup>&deg;</sup>C</div>
            </div>
        </div>
    )
}

export default WeatherItem
