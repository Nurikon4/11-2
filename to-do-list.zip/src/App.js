import './App.css';
import React from 'react';


class App extends React.Component {

  // state = {
  //   tasks: ["Купить молоко", "Купить хлеб"]
  // }

  // addTask = () => {
  //   const newTasks = this.state.tasks
  //   newTasks.push("asdasdasdasd")
  //   this.setState({
  //     tasks: newTasks
  //   })
  // }


  render() {
    return (
      <div>
        <div className='container'>
          <h2>To-Do-List</h2>
          <div className='Add'>
            <input className='input' placeholder='Введите задачу' type="text"></input>
            <a className='button' onClick={this.addTask} href='#'>ADD</a>
            {/* <a className='button' onClick={this.addTask} href='#'>ADD</a> */}
          </div>

          <div className='message'>
            <ul>

              {/* {this.state.tasks.map(task => {
                return (
                  <li>
                    <span>{task}</span>
                    <div>
                      <button>Apply</button>
                      <button>Remove</button>
                    </div>
                  </li>
                )
              })} */}



            </ul>
          </div>

          <h2>Выполнино</h2>

          <ul>
            <li>
              Купить молоко
            </li>

            <li>
              Купить хлеб
            </li>
          </ul>

        </div>
      </div>)
  }
}

export default App;
