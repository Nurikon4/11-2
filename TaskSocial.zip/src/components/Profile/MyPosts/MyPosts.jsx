import classes  from './MyPosts.module.css'
import Post from './Post/Post'


let postData = [
    {id: 1, message: 'TTT', likescount: 12},
    {id: 2, message: 'EEE', likescount: 15},
    {id: 3, message: 'Hellow', likescount: 20},
    {id: 4, message: 'SSS', likescount: 25},
    {id: 5, message: 'TTT', likescount: 12},
    {id: 6, message: 'r', likescount: 12}
]

let postsElemts = postData
.map( p => <Post message={p.message} likescount={p.likescount}/>)

const MyPosts= () => {
    return (
        <div className={classes.postsBlock}>
            <h3>My posts</h3>
            <div>
                <div>
                    <textarea></textarea>
                </div>
            
                <div>
                    <button>Add post</button>
                </div>
            </div>
            <div className="posts">
                {postsElemts}
            </div>
        </div>
    )
}
    export default MyPosts