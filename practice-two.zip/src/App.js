import './App.css';
import React, { Component } from 'react';
import Car from './Car/Car';

class App extends Component {

  constructor(props) {
    console.log('App Constructor');
    super(props)

    this.state =  {
      cars: [
        { name: 'Ford', year: 2018 },
        { name: 'Audi', year: 2016 },
        { name: 'Mazda', year: 2010 }
      ],
      pageTitle: 'React',
      showCars: false
    }
  }

  changeTitle = (CarName) => {
    this.setState({
      pageTitle: CarName
    })
  }
  showCarsBlock = () => {
    this.setState({
      showCars: !this.state.showCars
    })
  }
  inputChange(name, index) {
    const car = this.state.cars[index]
    car.name = name
    const cars = [...this.state.cars]
    cars[index] = car
    this.setState({
      cars: cars
    })
  }
  deleteHandler(index) {
    const cars = this.state.cars.concat()
    cars.splice(index, 1)

    this.setState({
      cars
    })
  }

  componentWillMount() {
    console.log('App componentWillMount');
  }
  componentDidMount() {
    console.log('App componentDidMount');
  }

  render() {
    console.log('App render');
    let cars = null

    if (this.state.showCars) {
      cars = this.state.cars.map((car, index) => {
        return (
          <Car
            key={index}
            name={car.name}
            year={car.year}
            changeTitle={() => this.changeTitle(car.name)}
            onDelte={this.deleteHandler.bind(this, index)}
            inputChange={(event) => this.inputChange(event.target.value, index)}
          />
        )
      })
    }
    return (
      <div style={{ textAlign: 'center' }}>
        <h1>{this.props.title}</h1>
        <button onClick={this.showCarsBlock}>Change title</button>
        <div className='carsWrapper'>
          {cars}
        </div>
      </div>
    )
  }
}

export default App;
