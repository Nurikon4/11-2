import { render } from '@testing-library/react'
import React, { Component } from 'react'
import classes from './Car.module.css'

    class Car extends Component {
        render() {
            const inputClasses = [classes.input]

            if(this.props.name !== '') {
                inputClasses.push(classes.green)
            } else {
                inputClasses.push(classes.red)
            }
        
            if(this.props.name.length > 4) {
                inputClasses.push(classes.bold)
            }
        
            return (
                <div className={classes.car}>
                    <h2>Car name: {this.props.name}</h2>
                    <p>Year: {this.props.year}</p>
                    <input 
                    onChange={this.props.inputChange}
                    type='text' 
                    value={this.props.name}
                    className={inputClasses.join(' ')}
                    
                    >
                    </input>
                    <button onClick={this.props.onDelte}>Delete</button>
                </div>
            )
        }
    }

export default Car