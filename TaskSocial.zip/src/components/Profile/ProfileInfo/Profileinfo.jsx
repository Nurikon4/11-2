import classes  from './Profileinfo.module.css'

const Profileinfo= () => {
    return (
        <div>
            <div>
                <img className={classes.content__top} src='http://bgfons.com/uploads/light/light_texture2184.jpg'/>
            </div>
            
            <div className={classes.description}>
                ava+description
            </div>
        </div>
    )
}
    export default Profileinfo