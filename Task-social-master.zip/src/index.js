import {rerenderEntireTree} from './render'
import './index.css';
import state from "./redux/state";


rerenderEntireTree(state);

