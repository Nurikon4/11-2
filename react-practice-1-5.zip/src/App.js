import './App.css';
import React, { Component } from 'react';
import Car from './Car/Car';
import ErrorBoundary from './ErrorBoundary/ErrorBoundary';
import Counter from './Counter/Counter';

export const ClickedContext = React.createContext(false)

class App extends Component {

  constructor(props) {
    super(props)

    this.state = {
      clicked: false,
      cars: [
        { name: 'Ford', year: 2018 },
        { name: 'Audi', year: 2016 },
        { name: 'Mazda', year: 2010 }
      ],
      pageTitle: 'React',
      showCars: false
    }
  }

  changeTitle = (CarName) => {
    this.setState({
      pageTitle: CarName
    })
  }
  showCarsBlock = () => {
    this.setState({
      showCars: !this.state.showCars
    })
  }
  inputChange(name, index) {
    const car = this.state.cars[index]
    car.name = name
    const cars = [...this.state.cars]
    cars[index] = car
    this.setState({
      cars: cars
    })
  }
  deleteHandler(index) {
    const cars = this.state.cars.concat()
    cars.splice(index, 1)

    this.setState({
      cars
    })
  }

  render() {
    let cars = null

    if (this.state.showCars) {
      cars = this.state.cars.map((car, index) => {
        return (
          <ErrorBoundary key={index}>
            <Car              
              name={car.name}
              year={car.year}
              changeTitle={() => this.changeTitle(car.name)}
              onDelte={this.deleteHandler.bind(this, index)}
              inputChange={(event) => this.inputChange(event.target.value, index)}
            />
          </ErrorBoundary>
        )
      })
    }
    return (
      <div style={{ textAlign: 'center' }}>

        <ClickedContext.Provider value={this.state.clicked}>
        <Counter/>
        </ClickedContext.Provider>
        
        <br />
        <button style={{marginTop: '20px'}} onClick={this.showCarsBlock}>Change title</button>
        
        <button onClick={ () => this.setState({clicked: true})}>Change clicked</button>
        <div className='carsWrapper'>
          {cars}
        </div>
      </div>
    )
  }
}

export default App;
