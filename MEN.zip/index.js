const express = require('express')
const mongoose = require('mongoose')
const exphbs = require('express-handlebars')
const todoRoutes = require('./routes/todos')

const PORT = process.env.PORT || 3000

const app = express()
const hbs = exphbs.create({
    defaultLayout: 'main',
    extname: 'hbs'
  })
  
  app.engine('hbs', hbs.engine)
  app.set('view engine', 'hbs')
  app.set('views', 'views')

  app.use(express.urlencoded({extended: true}))

  app.use(todoRoutes)

  async function start() {
    try {
      await mongoose.connect(
        'mongodb+srv://nurik:1q2w3e4r5t@cluster0.zmxpy.mongodb.net/todos',
        {
          useNewUrlParser: true,
          useUnifiedTopology: true,
          useFindAndModify: false
        },
        function(err){
          if(err)console.log('err');
        }
      )
      app.listen(PORT, () => {
        console.log(`Server is starting in port ${PORT}...`);
    })
    } catch (e) {
      console.log(e)
    }
  }
  
  start()