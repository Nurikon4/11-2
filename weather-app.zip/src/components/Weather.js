import classes from './Weather.module.css'
import { fetchWeather } from '../api/fetchWeather'
import cities from '../db/city.json'
import { NavLink } from "react-router-dom"

import { useEffect, useState } from 'react'
import Loader from '../Loader/Loader'

function Weather() {
    const [query, setQuery] = useState('')
    const [weather, setWeather] = useState([])

    
    useEffect( () => {
        const raw = localStorage.getItem('weather') || []
        setWeather(JSON.parse(raw))
    }, [])

    useEffect( () => {
        localStorage.setItem('weather', JSON.stringify(weather))
    }, [weather])

    const search = async (e) => {
        if (e.key == 'Enter' || e.type == 'click') {
            const data = await fetchWeather(query)
            setWeather(data)
            setQuery('')
        }
    }
    let info
    if (weather.main) {
        switch (weather.weather[0].main) {
            case 'Clouds':
                info = 'Облачно'
                break
            case 'Clear':
                info = 'Ясно'
                break
            case 'Mist':
                info = 'Атмосферное явление'
                break
            case 'Snow':
                info = 'Снег'
                break
            case 'Rain':
                info = 'Дождь'
                break
            case 'Drizzle':
                info = 'Морось'
                break
            case 'Thunderstorm':
                info = 'Гроза'
                break
        }
    }

    console.log(weather);
    

    let citiesList = cities.map((city, index) => <option value={`${city.name}`} key={index} />)

    console.log(weather.main)


    return (
        <>
            <div>
                <input
                    list="cities"
                    type="text"
                    className={classes.search}
                    placeholder="Введите город"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    onKeyPress={search}
                />
                <datalist id="cities">
                    {citiesList}
                </datalist>
                <button className={classes.btn} onClick={search}></button>
            </div>

            {weather.main
            ? <div className={classes.weather}>
                    <h1 className={classes.city}>{weather.name}</h1>
                    <span className={classes.more}>
                        <NavLink to='/more' className={classes.more__link}>Нажмите для подробного прогноза</NavLink>
                    </span>
                    <div className={classes.degree__block}>
                        <img className={classes.img} src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}></img>
                        <div className={classes.degree}>{Math.round(weather.main.temp)}<sup>&deg;</sup>С</div>
                    </div>
                    <div className={classes.info}>{info}</div>
                    <div className={classes.how}>Ощущается как: {Math.round(weather.main.feels_like)}<sup>&deg;</sup>C</div>
                </div>
                : <Loader />
            }
        </>
    )
}

export default Weather
