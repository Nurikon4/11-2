import DialogsItem from './Dialogitem/Dialogsitem'
import classes from './Dialogs.module.css'
import Message from './Message/message'


const Dialogs = (props) => {

    let dialogsElemnts = props.diaglogsData
    .map ( dialog => <DialogsItem name={dialog.name} id={dialog.id}/> ) 
    
    let messagesElements = props.messages
    .map ( message => <Message message={message.message}/> )

    return (
        <div className={classes.dialogs}>
            <div className={classes.dialogsItems}>
                {dialogsElemnts}
            </div>
            <div className={classes.messages}>
                {messagesElements}
            </div>
        </div>
    )
}

export default Dialogs