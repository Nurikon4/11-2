import Container from "./Container/Container"
import classes from './MoreWeather.module.css'


function MoreWeather({weather, moreWeather}) {

    return (
        <div className={classes.MoreWeather}>
            <h1 className={classes.uptitle}>{weather.name}</h1>
            <Container moreWeather={moreWeather} data={'Сегодня'}/>
            <Container moreWeather={moreWeather} data={'Завтра'}/>
            <Container moreWeather={moreWeather} data={'Послезавтра'}/>
            <Container moreWeather={moreWeather} data={moreWeather.list[20].dt_txt.replace('2021-', '').replace('00:00:00', '')}/>
            <Container moreWeather={moreWeather} data={moreWeather.list[28].dt_txt.replace('2021-', '').replace('00:00:00', '')}/>
        </div>
    )
}
export default MoreWeather
